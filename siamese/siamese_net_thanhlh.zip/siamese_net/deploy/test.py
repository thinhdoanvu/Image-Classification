import torch
import numpy as np
from torch.utils.data import DataLoader
import argparse
import yaml
import torchvision
import itertools
import matplotlib.pyplot as plt

def test_model():
    model.eval()
    preds = []
    labels = []
    perf = 0

    with torch.no_grad():
        for i, data in enumerate(test_loader):
            img, _, _, label, _, _ = data
            # img, label = data
            img = img.cuda()

            # Perform a forward pass to get the logits
            _, logits = model(img)

            # Produce the predictive label
            pred = logits.cpu().detach().numpy().argmax(axis=1)[0]  # because the batch size is 1, so we just take the 1st item

            # Store the results for further computation
            preds.append(pred)
            labels.append(label.item())

    return np.array(preds), np.array(labels)

if __name__ == '__main__':
    # 1. Parse the command arguments
    args = argparse.ArgumentParser(description='Test a trained Siamese CCT for SAR image classification')
    args.add_argument('-i', '--input', default=None, type=str,
                      help='Path of either i) a single input image or ii) an image folder')
    args.add_argument('-s', '--img-size', default=64, type=int, help='Image size')
    args.add_argument('-n', '--num-class', default=3, type=int, help='Number of vessel classes')
    args.add_argument('-w', '--weights', default='weights/.pt', type=str, help='Path of the trained weights')
    cmd_args = args.parse_args()

    # 2. Setup CUDA
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 3. Create a new model
    from model.cct import CCT
    model = CCT(img_size=cmd_args.img_size,
                embedding_dim=384,
                n_conv_layers=2,
                kernel_size=7,
                stride=2,
                padding=3,
                pooling_kernel_size=3,
                pooling_stride=2,
                pooling_padding=1,
                num_layers=14,
                num_heads=6,
                mlp_radio=3., # must be "radio", not "ratio". They are different
                num_classes=cmd_args.num_class,
                positional_embedding='learnable').to(device)
    model.load_state_dict(torch.load(weights, device))
    print('The trained CCT model loaded')

    # 5. Test the model
    preds, labels = test_model()
    np.mean(preds == labels)

    cm = confusion_matrix(labels, preds)
    plot_confusion_matrix(cm, ['cargo', 'fishing', 'military'])
