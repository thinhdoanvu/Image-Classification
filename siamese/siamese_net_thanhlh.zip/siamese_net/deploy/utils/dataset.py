from torch.utils.data import Dataset
import random
from PIL import Image
import torch
import numpy as np
import cv2
import torchvision.transforms as T
from utils.utils import form_3channel_image

class SiameseNetworkDataset(Dataset):

    def __init__(self, image_dataset, img_size=128, preprocess=False, train=True):
        self.image_dataset = image_dataset
        self.img_size = img_size
        self.preprocess = preprocess
        self.train = train

    def __getitem__(self, index):

        if self.train:  # for training
            anchor = random.choice(self.image_dataset.imgs)  # return a tuple: file path (string) vs. class label (int)
            a_label = anchor[1]

            # Get a random positive
            while True:
                positive = random.choice(self.image_dataset.imgs)
                p_label = positive[1]
                if a_label == p_label:  # until a positive (i.e., same class) is found
                    break

            # Get a random negative
            while True:
                negative = random.choice(self.image_dataset.imgs)
                n_label = negative[1]
                if a_label != n_label:  # until a negative (i.e., different class) is found
                    break

            # Read the triplets
            a = cv2.imread(anchor[0])  # use OpenCV to read uint16 images
            p = cv2.imread(positive[0])
            n = cv2.imread(negative[0])

            # OPTION 1: Obtain 3-channel image using the pre-processing technique as the reference: J. A. Raj, S. M. Idicula and B. Paul, "One-shot learning-based SAR ship classification using new hybrid Siamese network", IEEE Geoscience and Remote Sensing Letters, pp. 1-5, 2021.
            if self.preprocess:
                a = form_3channel_image(a)
                a = Image.fromarray(a)

                p = form_3channel_image(p)
                p = Image.fromarray(p)

                n = form_3channel_image(n)
                n = Image.fromarray(n)
            else:
                # OPTION 2: Convert to RGB images as normal
                a = Image.fromarray(a)  # RGB conversion included
                p = Image.fromarray(p)
                n = Image.fromarray(n)

            # Process and convert the triplets to tensors
            a = T.Resize((self.img_size, self.img_size), interpolation=T.InterpolationMode.BILINEAR)(a)  # must pass a tuple because 'T.Resize' behaves differently on input images with a different height and width
            a = T.ToTensor()(a)
            a_label = torch.tensor(a_label)

            p = T.Resize((self.img_size, self.img_size), interpolation=T.InterpolationMode.BILINEAR)(p)
            p = T.ToTensor()(p)
            p_label = torch.tensor(p_label)

            n = T.Resize((self.img_size, self.img_size), interpolation=T.InterpolationMode.BILINEAR)(n)  # Option 2: T.InterpolationMode.BILINEAR
            n = T.ToTensor()(n)
            n_label = torch.tensor(n_label)

            return a, p, n, a_label, p_label, n_label

        else:  # for testing
            file = self.image_dataset.imgs[index]
            img = cv2.imread(file[0])
            img = Image.fromarray(img)
            img = T.Resize((self.img_size, self.img_size), interpolation=T.InterpolationMode.BILINEAR)(img)  # must pass a tuple because 'T.Resize' behaves differently on input images with a different height and width
            img = T.ToTensor()(img)
            label = torch.tensor(file[1])
            return img, label


    def __len__(self):
        return len(self.image_dataset.imgs)