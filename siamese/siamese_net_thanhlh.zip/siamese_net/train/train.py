import os
import torch
import numpy as np
from torch.utils.data import DataLoader
from tqdm import tqdm
from torch import optim
import yaml
from utils.dataset import SiameseNetworkDataset
from sklearn.metrics import confusion_matrix, accuracy_score
import torchvision


def train_model():
    model.train()
    losses = 0
    perf = 0

    for i, data in enumerate(tqdm(train_loader)):
        a, p, n, a_label, _, _ = data
        a, p, n, a_label = a.cuda(), p.cuda(), n.cuda(), a_label.cuda()

        a_embed, logits = model(a)
        p_embed, _ = model(p)
        n_embed, _ = model(n)
        loss = alpha * criterion_1(a_embed, p_embed, n_embed) + (1 - alpha) * criterion_2(logits, a_label)
        losses += loss.item()

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # Compute the accuracy of the classification branch
        pred = logits.cpu().detach().numpy().argmax(axis=1)
        label = a_label.cpu().detach().numpy()
        perf += np.mean(pred == label)

    return losses / len(train_loader), perf / len(train_loader)


def validate_model():
    model.eval()
    preds = []
    labels = []

    with torch.no_grad():
        for i, data in enumerate(test_loader):
            a, p, n, a_label, _, _ = data
            a, p, n, a_label = a.cuda(), p.cuda(), n.cuda(), a_label.cuda()

            _, logits = model(a)

            # Compute the accuracy of the classification branch
            pred = logits.cpu().detach().numpy().argmax(axis=1)

           # Store the results for further computation
            preds.append(pred)
            labels.append(a_label.item())  # the test batch-size is 1, so we can use 'item()' instead of 'cpu().detach().numpy()'

        preds = np.array(preds)
        labels = np.array(labels)
        cm = confusion_matrix(labels, preds)
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

        return accuracy_score(labels, preds), cm.diagonal()[0], cm.diagonal()[1], cm.diagonal()[2]
#
# def test_model():
#     model.eval()
#     preds = []
#     labels = []
#
#     with torch.no_grad():
#         for i, data in enumerate(test_loader):
#             img, label = data
#             img = img.cuda()
#
#             # Perform a forward pass to get the logits
#             _, logits = model(img)
#
#             # Produce the predictive label
#             pred = logits.cpu().detach().numpy().argmax(axis=1)[0]  # because the batch size is 1, so we just take the 1st item
#
#             # Store the results for further computation
#             preds.append(pred)
#             labels.append(label.item())
#
#     preds = np.array(preds)
#     labels = np.array(labels)
#     cm = confusion_matrix(labels, preds)
#     cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
#
#     return np.mean(preds == labels), cm.diagonal()[0], cm.diagonal()[1], cm.diagonal()[2]


if __name__ == '__main__':

    # 1. Setup CUDA
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 2. Load the configurations from the yaml file
    config_path = 'config/config.yml'
    with open(config_path) as file:
        cfg = yaml.safe_load(file)
    img_size = cfg['train_params']['img_size']
    num_class = cfg['train_params']['num_class']
    train_path = cfg['train_params']['train_path']
    test_path = cfg['train_params']['test_path']
    batch_size = cfg['train_params']['batch_size']
    num_workers = cfg['train_params']['num_workers']
    learning_rate = cfg['train_params']['learning_rate']
    margin = cfg['train_params']['margin']
    alpha = float(cfg['train_params']['alpha'])
    epochs = cfg['train_params']['epochs']
    out_path = cfg['train_params']['out_path']
    preprocess = cfg['train_params']['preprocess']
    backbone = cfg['train_params']['backbone']
    print(cfg)

    # 3. Load the dataset
    train_dataset = SiameseNetworkDataset(image_dataset=torchvision.datasets.ImageFolder(root=train_path),
                                          img_size=img_size,
                                          preprocess=preprocess,
                                          train=True)
    train_loader = DataLoader(train_dataset,
                              shuffle=True,
                              num_workers=num_workers,
                              batch_size=batch_size)

    test_dataset = SiameseNetworkDataset(image_dataset=torchvision.datasets.ImageFolder(root=test_path),
                                         img_size=img_size,
                                         preprocess=preprocess,
                                         train=True)  # turn on/off the test mode
    test_loader = DataLoader(test_dataset,
                             shuffle=True,
                             num_workers=num_workers,
                             batch_size=1)

    #  4. Create a new model
    if backbone == 'cct':  # OPTION 1: use CCT as the backbone
        from model.cct import CCT
        model = CCT(img_size=img_size,
                    embedding_dim=288,
                    n_conv_layers=2,
                    kernel_size=7,
                    stride=2,
                    padding=3,
                    pooling_kernel_size=3,
                    pooling_stride=2,
                    pooling_padding=1,
                    num_layers=14,
                    num_heads=24, # 'embedding_dim' must be a multiple of 'num_heads'
                    mlp_radio=3.,  # must be "radio", not "ratio"
                    num_classes=num_class,
                    positional_embedding='learnable').to(device)

    else: # OPTION 2: use other pre-trained CNNs as the backbone
        from model.siamese_network import SiameseTriplet
        model = SiameseTriplet(backbone=backbone, num_class=num_class).to(device)

    # 5. Specify loss function and optimizer
    criterion_1 = torch.nn.TripletMarginLoss(margin=margin, p=2)
    criterion_2 = torch.nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    # 6. Start training the model
    best_acc = 0
    for epoch in range(epochs):

        # 6.1. Train the model over a single epoch
        train_loss, train_acc = train_model()
        print('Epoch {}: \tTraining loss = {:.4f}\t Training accuracy = {:.4f}\t'.format(epoch, train_loss, train_acc))

        # 6.2. Validate the model
        # val_loss, val_acc = validate_model()
        # print('\t\tValidation loss = {:.4f}\t Validation accuracy = {:.4f}\t'.format(val_loss, val_acc))

        val_acc, cargo_acc, fishing_acc, military_acc = validate_model()
        print('\t\t Validation accuracy:  Overall = {:.4f} \t Cargo = {:.4f} \t Fishing = {:.4f} \t Military = {:.4f}\t'.format(val_acc, cargo_acc, fishing_acc, military_acc))

        # 6.3. Save the model if the validation performance is increasing
        if val_acc > best_acc:
            torch.save(model.state_dict(), os.path.join(out_path, backbone + '_epoch_' + str(epoch) + '_acc_{0:.4f}'.format(val_acc) + '.pth'))
            print('Accuracy increased ({:.4f} --> {:.4f}). Model saved'.format(best_acc, val_acc))
            best_acc = val_acc