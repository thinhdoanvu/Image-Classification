import torch
import torch.nn as nn
from torchvision import models
import torch.nn.functional as F


class SiameseTriplet(nn.Module):
    def __init__(self, backbone='resnet34', num_class=3):
        """
        backbone: https://pytorch.org/vision/stable/models.html
        """
        super().__init__()

        if backbone not in models.__dict__:
            raise Exception("No model named {} exists in torchvision.models.".format(backbone))

        # Create a backbone network from the pretrained models provided in torchvision.models
        self.backbone = models.__dict__[backbone](pretrained=True, progress=True)
        self.fc1 = nn.Linear(1000, 512)
        self.fc2 = nn.Linear(512, 128)
        self.fc3 = nn.Linear(128, num_class)


    def forward(self, x):
        """
        J. He, Y. Wang and H. Liu, "Ship classification in medium-resolution SAR images via densely connected triplet
        CNNs integrating Fisher discrimination regularized metric learning", IEEE Trans. on Geoscience and Remote
        Sensing, vol. 59, no. 4, pp. 3022-3039, 2021.
        """
        x = self.backbone(x)
        # # x = x.view(x.size()[0], -1) # flatten
        x = torch.flatten(x, 1) # flatten all dimensions except batch
        x = F.relu(self.fc1(x))
        x = F.normalize(x, dim=0, p=2) # output embedding for triplet loss
        x = F.relu(self.fc2(x))
        x = F.normalize(x, dim=0, p=2)  # output embedding for triplet loss

        logits = F.relu(self.fc3(x))  # output for cross-entropy classification loss
        return x, logits
