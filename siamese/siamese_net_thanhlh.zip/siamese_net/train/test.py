import torch
import numpy as np
from torch.utils.data import DataLoader
from tqdm import tqdm
import yaml
from utils.dataset import SiameseNetworkDataset
from sklearn.metrics import confusion_matrix
import torchvision
import itertools
import matplotlib.pyplot as plt


def plot_confusion_matrix(cm,
                          target_names,
                          title='',
                          cmap=None,
                          normalize=True):
    """
    given a sklearn confusion matrix (cm), make a nice plot
    Arguments
    ---------
    cm:           confusion matrix from sklearn.metrics.confusion_matrix
    target_names: given classification classes such as [0, 1, 2]
                  the class names, for example: ['high', 'medium', 'low']
    title:        the text to display at the top of the matrix
    cmap:         the gradient of the values displayed from matplotlib.pyplot.cm
                  see http://matplotlib.org/examples/color/colormaps_reference.html
                  plt.get_cmap('jet') or plt.cm.Blues
    normalize:    If False, plot the raw numbers
                  If True, plot the proportions
    Usage
    -----
    plot_confusion_matrix(cm           = cm,                  # confusion matrix created by sklearn.metrics.confusion_matrix
                          normalize    = True,                # show proportions
                          target_names = y_labels_vals,       # list of names of the classes
                          title        = best_estimator_name) # title of graph
    Citiation
    ---------
    http://scikit-learn.org/stable/auto_examples/model_selection/plot_confusion_matrix.html
    """
    accuracy = np.trace(cm) / np.sum(cm).astype('float')
    misclass = 1 - accuracy

    if cmap is None:
        cmap = plt.get_cmap('Blues')

    fig = plt.figure(figsize=(8, 7))
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()

    if target_names is not None:
        tick_marks = np.arange(len(target_names))
        plt.xticks(tick_marks, target_names, rotation=45)
        plt.yticks(tick_marks, target_names)

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

    thresh = cm.max() / 1.5 if normalize else cm.max() / 2
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        if normalize:
            plt.text(j, i, "{:0.4f}".format(cm[i, j]),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")
        else:
            plt.text(j, i, "{:,}".format(cm[i, j]),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")

    plt.tight_layout()
    plt.ylabel('True label', fontsize=16)
    plt.xlabel('Predicted label\naccuracy={:0.4f}; mis-classified={:0.4f}'.format(accuracy, misclass), fontsize=16)
    plt.show()
    fig.savefig('confusion_matrix.png', bbox_inches='tight', dpi=600)

def test_model():
    model.eval()
    preds = []
    labels = []
    perf = 0

    with torch.no_grad():
        for i, data in enumerate(test_loader):
            img, _, _, label, _, _ = data
            # img, label = data
            img = img.cuda()

            # Perform a forward pass to get the logits
            _, logits = model(img)

            # Produce the predictive label
            pred = logits.cpu().detach().numpy().argmax(axis=1)[0]  # because the batch size is 1, so we just take the 1st item

            # Store the results for further computation
            preds.append(pred)
            labels.append(label.item())

    return np.array(preds), np.array(labels)

if __name__ == '__main__':
    # 1. Setup CUDA
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # 2. Load the configurations from the yaml file
    config_path = 'config/config.yml'
    with open(config_path) as file:
        cfg = yaml.safe_load(file)
    img_size = cfg['train_params']['img_size']
    num_class = cfg['train_params']['num_class']
    test_path = cfg['train_params']['test_path']
    preprocess = cfg['train_params']['preprocess']
    num_workers = cfg['train_params']['num_workers']
    weights = cfg['train_params']['weights']
    print(cfg)

    # 3. Load the dataset
    test_dataset = SiameseNetworkDataset(image_dataset=torchvision.datasets.ImageFolder(root=test_path),
                                         img_size=img_size,
                                         preprocess=preprocess,
                                         train=True)
    test_loader = DataLoader(test_dataset,
                             shuffle=True,
                             num_workers=num_workers,
                             batch_size=1)  # must be 1


    #  4. Create a new model
    from model.cct import CCT
    model = CCT(img_size=img_size,
                embedding_dim=384,
                n_conv_layers=2,
                kernel_size=7,
                stride=2,
                padding=3,
                pooling_kernel_size=3,
                pooling_stride=2,
                pooling_padding=1,
                num_layers=14,
                num_heads=6,
                mlp_radio=3., # must be "radio", not "ratio". They are different
                num_classes=num_class,
                positional_embedding='learnable').to(device)
    model.load_state_dict(torch.load(weights, device))
    print('The trained CCT model loaded')

    # 5. Test the model
    preds, labels = test_model()
    np.mean(preds == labels)

    cm = confusion_matrix(labels, preds)
    plot_confusion_matrix(cm, ['cargo', 'fishing', 'military'])
